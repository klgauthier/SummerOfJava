SummerOfJava
============

Repository for programming workshop 4 of week 8.

Your task is to make your own class, named after yourself (ex: KevinGauthier) which extends the person class.
Person has an abstract method called getSaying which returns a String. You must make your own implementation of 
this method and return your own personalized saying (ex: "Fact. Bears eat beets. Bears. Beets. Battlestar Galactica").
