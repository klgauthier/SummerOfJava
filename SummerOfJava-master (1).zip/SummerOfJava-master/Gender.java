
/**
 * Enum class representing gender
 * 
 * @author Kevin Gauthier
 * @version 07.07.14
 */
public enum Gender
{
    MALE, FEMALE, OTHER
}
